package stepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class step {

	WebDriver driver;
	@Given("^Open the Chrome browser and launch the google$")
	public void open_the_Chrome_browser_and_launch_the_google() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
	    System.setProperty("webdriver.chrome.driver","C:\\Users\\Munagala\\eclipse-workspace\\reskilltraining\\target\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		Thread.sleep(4000);
		System.out.println("Browser is opened");
	}

	@When("^i enter selenium and search$")
	public void i_enter_selenium_and_search() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	    driver.findElement(By.name("q")).sendKeys("Selenium");
		Thread.sleep(5000);
		driver.findElement(By.name("btnK")).click();
		System.out.println("entered 'Selenium' on search box and click on enter");
	}

	@Then("^should display the results and open the link$")
	public void should_display_the_results_and_open_the_link() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"rso\"]/div[1]/div/div/div/div/div/div/div[1]/a/h3")).click();
		System.out.println("Selected the link and navigated to desired page");
		System.out.println("URL:"+driver.getCurrentUrl());
		driver.close();
	}
	
}
